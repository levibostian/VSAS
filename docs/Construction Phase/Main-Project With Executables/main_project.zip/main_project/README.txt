*-----------------------------------------------------------------------------*
*                                                                             *
* README.txt                                                                  *
*                                                                             *
* NOTE: This is NOT official documentation for the project. It is simply      *
*       a README file for our production sake. For repo only.                 *
*-----------------------------------------------------------------------------*

Not much to add here yet. May add more once meeting with customer.
