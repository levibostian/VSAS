The VSAS folder is a mess of Files. I'm sorry for that. I tried using subfolders but the imports were all screwed up, and I couldn't figure out how to fix them. Anyway...


If you have everything downloaded and want to run the GUI/w the Motion Detection you have to open the VSAS.py file and run it. Everything should work! If you have problems please let me know. openCV is probably going to cause problems with all the different versions. 

Kristen, I edited your VSASmainScreen file a little bit. There's an extra method, and a few things moved around. As I'm writing this I realize I may have screwed the GUI up from being able to run independently. If you're wondering about decisions I made in it let me know. I had to comment certain things out to make it work with Threading. 

Test it out, see how it works! 