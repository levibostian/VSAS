from MotionDetector import *

motion = MotionDetector()
